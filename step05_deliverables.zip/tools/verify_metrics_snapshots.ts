/**
 * verify_metrics_snapshots.ts
 *
 * End-to-end validation script for the KPI snapshot system.
 * Creates seed data, runs compute functions, and verifies results.
 *
 * Usage:
 *   npx tsx tools/verify_metrics_snapshots.ts
 *
 * Requires env vars: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
 */

import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SERVICE_KEY) {
  console.error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  process.exit(1);
}

const db = createClient(SUPABASE_URL, SERVICE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
});

const DAY_MS = 86_400_000;
const NOW = Date.now();
const TODAY = new Date(NOW - (NOW % DAY_MS));
const YESTERDAY = new Date(TODAY.getTime() - DAY_MS);
const YESTERDAY_STR = YESTERDAY.toISOString().slice(0, 10);

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`FAIL: ${message}`);
    process.exit(1);
  }
  console.log(`  PASS: ${message}`);
}

// ── Seed data ──────────────────────────────────────────────────────────────

const GROUP_A_ID = "aaaaaaaa-0000-0000-0000-000000000001";
const GROUP_B_ID = "bbbbbbbb-0000-0000-0000-000000000002";
const COACH_A_ID = "cccccccc-0000-0000-0000-000000000001";
const COACH_B_ID = "cccccccc-0000-0000-0000-000000000002";
const ATHLETE_A1 = "dddddddd-0000-0000-0000-000000000001";
const ATHLETE_A2 = "dddddddd-0000-0000-0000-000000000002";
const ATHLETE_B1 = "dddddddd-0000-0000-0000-000000000003";
const ATHLETE_B2 = "dddddddd-0000-0000-0000-000000000004";

async function seedData() {
  console.log("\n── Seeding test data ──");

  // Ensure test users exist in auth.users (service_role can create)
  const userIds = [COACH_A_ID, COACH_B_ID, ATHLETE_A1, ATHLETE_A2, ATHLETE_B1, ATHLETE_B2];
  for (const uid of userIds) {
    const { error } = await db.auth.admin.createUser({
      id: uid,
      email: `test-${uid.slice(0, 8)}@verify.test`,
      password: "test-password-123!",
      email_confirm: true,
    });
    if (error && !error.message.includes("already")) {
      console.warn(`User create warn (${uid}): ${error.message}`);
    }
  }

  // Groups
  for (const [id, name, coachId] of [
    [GROUP_A_ID, "Test Group A", COACH_A_ID],
    [GROUP_B_ID, "Test Group B", COACH_B_ID],
  ] as const) {
    await db.from("coaching_groups").upsert({
      id,
      name,
      coach_user_id: coachId,
      created_at_ms: NOW - 30 * DAY_MS,
    }, { onConflict: "id" });
  }

  // Members
  const members = [
    { id: crypto.randomUUID(), user_id: COACH_A_ID, group_id: GROUP_A_ID, display_name: "Coach A", role: "admin_master", joined_at_ms: NOW - 30 * DAY_MS },
    { id: crypto.randomUUID(), user_id: ATHLETE_A1, group_id: GROUP_A_ID, display_name: "Athlete A1", role: "atleta", joined_at_ms: NOW - 20 * DAY_MS },
    { id: crypto.randomUUID(), user_id: ATHLETE_A2, group_id: GROUP_A_ID, display_name: "Athlete A2", role: "atleta", joined_at_ms: NOW - 15 * DAY_MS },
    { id: crypto.randomUUID(), user_id: COACH_B_ID, group_id: GROUP_B_ID, display_name: "Coach B", role: "admin_master", joined_at_ms: NOW - 30 * DAY_MS },
    { id: crypto.randomUUID(), user_id: ATHLETE_B1, group_id: GROUP_B_ID, display_name: "Athlete B1", role: "atleta", joined_at_ms: NOW - 10 * DAY_MS },
    { id: crypto.randomUUID(), user_id: ATHLETE_B2, group_id: GROUP_B_ID, display_name: "Athlete B2", role: "atleta", joined_at_ms: NOW - 5 * DAY_MS },
  ];

  // Clear existing test members
  await db.from("coaching_members").delete().in("group_id", [GROUP_A_ID, GROUP_B_ID]);
  const { error: memErr } = await db.from("coaching_members").insert(members);
  if (memErr) console.warn(`Members insert warn: ${memErr.message}`);

  // Profile progress (for streak)
  for (const uid of [ATHLETE_A1, ATHLETE_A2, ATHLETE_B1, ATHLETE_B2]) {
    await db.from("profile_progress").upsert({
      user_id: uid,
      daily_streak_count: uid === ATHLETE_A1 ? 5 : 0,
    }, { onConflict: "user_id" });
  }

  // Sessions: inject 3 sessions for yesterday
  const sessions = [
    // A1: 2 sessions yesterday (active athlete)
    {
      id: crypto.randomUUID(),
      user_id: ATHLETE_A1,
      status: 3,
      start_time_ms: YESTERDAY.getTime() + 8 * 3600000,
      end_time_ms: YESTERDAY.getTime() + 9 * 3600000,
      total_distance_m: 5000,
      moving_ms: 3600000,
      is_verified: true,
    },
    {
      id: crypto.randomUUID(),
      user_id: ATHLETE_A1,
      status: 3,
      start_time_ms: YESTERDAY.getTime() + 17 * 3600000,
      end_time_ms: YESTERDAY.getTime() + 18 * 3600000,
      total_distance_m: 3000,
      moving_ms: 2400000,
      is_verified: true,
    },
    // B1: 1 session yesterday
    {
      id: crypto.randomUUID(),
      user_id: ATHLETE_B1,
      status: 3,
      start_time_ms: YESTERDAY.getTime() + 10 * 3600000,
      end_time_ms: YESTERDAY.getTime() + 11 * 3600000,
      total_distance_m: 7000,
      moving_ms: 4200000,
      is_verified: true,
    },
  ];

  const { error: sessErr } = await db.from("sessions").insert(sessions);
  if (sessErr) console.warn(`Sessions insert warn: ${sessErr.message}`);

  console.log("  Seed complete: 2 groups, 4 athletes, 3 sessions");
}

// ── Run compute jobs ───────────────────────────────────────────────────────

async function runCompute() {
  console.log("\n── Running compute functions ──");

  const { data: kpiCount, error: e1 } = await db.rpc(
    "compute_coaching_kpis_daily",
    { p_day: YESTERDAY_STR },
  );
  if (e1) throw new Error(`compute_coaching_kpis_daily failed: ${e1.message}`);
  console.log(`  Group KPIs computed: ${kpiCount} groups`);

  const { data: athleteCount, error: e2 } = await db.rpc(
    "compute_coaching_athlete_kpis_daily",
    { p_day: YESTERDAY_STR },
  );
  if (e2) throw new Error(`compute_coaching_athlete_kpis_daily failed: ${e2.message}`);
  console.log(`  Athlete KPIs computed: ${athleteCount} athletes`);

  const { data: alertCount, error: e3 } = await db.rpc(
    "compute_coaching_alerts_daily",
    { p_day: YESTERDAY_STR },
  );
  if (e3) throw new Error(`compute_coaching_alerts_daily failed: ${e3.message}`);
  console.log(`  Alerts generated: ${alertCount}`);
}

// ── Verify results ─────────────────────────────────────────────────────────

async function verify() {
  console.log("\n── Verifying results ──");

  // Group A KPIs
  const { data: kpiA } = await db
    .from("coaching_kpis_daily")
    .select("*")
    .eq("group_id", GROUP_A_ID)
    .eq("day", YESTERDAY_STR)
    .single();

  assert(kpiA !== null, "Group A KPI row exists");
  assert(kpiA!.total_athletes === 2, `Group A total_athletes = 2 (got ${kpiA!.total_athletes})`);
  assert(kpiA!.total_coaches === 1, `Group A total_coaches = 1 (got ${kpiA!.total_coaches})`);
  assert(kpiA!.dau === 1, `Group A DAU = 1 (A1 ran yesterday, got ${kpiA!.dau})`);
  assert(kpiA!.wau >= 1, `Group A WAU >= 1 (got ${kpiA!.wau})`);
  assert(kpiA!.sessions_today === 2, `Group A sessions_today = 2 (got ${kpiA!.sessions_today})`);
  assert(kpiA!.distance_today_m === 8000, `Group A distance = 8000m (got ${kpiA!.distance_today_m})`);
  assert(kpiA!.dau <= kpiA!.wau, "DAU <= WAU");
  assert(kpiA!.wau <= kpiA!.mau, "WAU <= MAU");
  assert(kpiA!.mau <= kpiA!.total_athletes, "MAU <= total_athletes");

  // Group B KPIs
  const { data: kpiB } = await db
    .from("coaching_kpis_daily")
    .select("*")
    .eq("group_id", GROUP_B_ID)
    .eq("day", YESTERDAY_STR)
    .single();

  assert(kpiB !== null, "Group B KPI row exists");
  assert(kpiB!.total_athletes === 2, `Group B total_athletes = 2 (got ${kpiB!.total_athletes})`);
  assert(kpiB!.dau === 1, `Group B DAU = 1 (B1 ran, got ${kpiB!.dau})`);
  assert(kpiB!.sessions_today === 1, `Group B sessions_today = 1 (got ${kpiB!.sessions_today})`);

  // Athlete KPIs
  const { data: akA1 } = await db
    .from("coaching_athlete_kpis_daily")
    .select("*")
    .eq("user_id", ATHLETE_A1)
    .eq("day", YESTERDAY_STR)
    .single();

  assert(akA1 !== null, "Athlete A1 KPI row exists");
  assert(akA1!.sessions_7d >= 2, `A1 sessions_7d >= 2 (got ${akA1!.sessions_7d})`);
  assert(akA1!.engagement_score > 0, `A1 engagement_score > 0 (got ${akA1!.engagement_score})`);
  assert(akA1!.engagement_score <= 100, "A1 score <= 100");
  assert(akA1!.risk_level === "ok" || akA1!.risk_level === "medium",
    `A1 risk_level is ok or medium (got ${akA1!.risk_level})`);
  assert(akA1!.current_streak === 5, `A1 streak = 5 (got ${akA1!.current_streak})`);

  // Athlete A2 (no sessions = high risk)
  const { data: akA2 } = await db
    .from("coaching_athlete_kpis_daily")
    .select("*")
    .eq("user_id", ATHLETE_A2)
    .eq("day", YESTERDAY_STR)
    .single();

  assert(akA2 !== null, "Athlete A2 KPI row exists");
  assert(akA2!.sessions_7d === 0, `A2 sessions_7d = 0 (got ${akA2!.sessions_7d})`);
  assert(akA2!.risk_level === "high", `A2 risk_level = high (got ${akA2!.risk_level})`);
  assert(akA2!.engagement_score < 20, `A2 score < 20 (got ${akA2!.engagement_score})`);

  // Invariants: sessions_7d <= sessions_14d <= sessions_30d
  const { data: allAthleteKpis } = await db
    .from("coaching_athlete_kpis_daily")
    .select("user_id, sessions_7d, sessions_14d, sessions_30d, engagement_score, risk_level")
    .eq("day", YESTERDAY_STR);

  for (const ak of allAthleteKpis ?? []) {
    assert(ak.sessions_7d <= ak.sessions_14d,
      `${ak.user_id.slice(0, 8)}: s7d(${ak.sessions_7d}) <= s14d(${ak.sessions_14d})`);
    assert(ak.sessions_14d <= ak.sessions_30d,
      `${ak.user_id.slice(0, 8)}: s14d(${ak.sessions_14d}) <= s30d(${ak.sessions_30d})`);
    assert(ak.engagement_score >= 0 && ak.engagement_score <= 100,
      `${ak.user_id.slice(0, 8)}: score in [0,100] (got ${ak.engagement_score})`);

    const expectedRisk =
      ak.engagement_score >= 40 ? "ok" :
      ak.engagement_score >= 20 ? "medium" : "high";
    assert(ak.risk_level === expectedRisk,
      `${ak.user_id.slice(0, 8)}: risk=${ak.risk_level} matches score=${ak.engagement_score}`);
  }

  // Alerts
  const { data: alerts } = await db
    .from("coaching_alerts")
    .select("*")
    .in("group_id", [GROUP_A_ID, GROUP_B_ID])
    .eq("day", YESTERDAY_STR);

  assert((alerts ?? []).length > 0, `Alerts generated: ${(alerts ?? []).length}`);

  const highRiskAlerts = (alerts ?? []).filter(
    (a: { alert_type: string }) => a.alert_type === "athlete_high_risk",
  );
  assert(highRiskAlerts.length >= 1,
    `At least 1 high-risk alert (A2 has no sessions, got ${highRiskAlerts.length})`);

  // RLS isolation: group A alerts don't contain group B users
  const groupAAlerts = (alerts ?? []).filter(
    (a: { group_id: string }) => a.group_id === GROUP_A_ID,
  );
  for (const a of groupAAlerts) {
    assert(
      a.user_id === null || [ATHLETE_A1, ATHLETE_A2, COACH_A_ID].includes(a.user_id),
      `Group A alert user is from group A (got ${a.user_id?.slice(0, 8)})`,
    );
  }

  // Idempotency: run compute again and verify counts don't double
  console.log("\n── Verifying idempotency ──");
  await db.rpc("compute_coaching_kpis_daily", { p_day: YESTERDAY_STR });

  const { data: kpiA2 } = await db
    .from("coaching_kpis_daily")
    .select("dau, sessions_today")
    .eq("group_id", GROUP_A_ID)
    .eq("day", YESTERDAY_STR)
    .single();

  assert(kpiA2!.dau === kpiA!.dau, `Idempotent: DAU still ${kpiA!.dau} after re-run`);
  assert(kpiA2!.sessions_today === kpiA!.sessions_today,
    `Idempotent: sessions still ${kpiA!.sessions_today} after re-run`);
}

// ── Cleanup ────────────────────────────────────────────────────────────────

async function cleanup() {
  console.log("\n── Cleaning up test data ──");
  await db.from("coaching_alerts").delete().in("group_id", [GROUP_A_ID, GROUP_B_ID]);
  await db.from("coaching_athlete_kpis_daily").delete().in("group_id", [GROUP_A_ID, GROUP_B_ID]);
  await db.from("coaching_kpis_daily").delete().in("group_id", [GROUP_A_ID, GROUP_B_ID]);
  await db.from("sessions").delete().in("user_id", [ATHLETE_A1, ATHLETE_A2, ATHLETE_B1, ATHLETE_B2]);
  await db.from("coaching_members").delete().in("group_id", [GROUP_A_ID, GROUP_B_ID]);
  await db.from("profile_progress").delete().in("user_id", [ATHLETE_A1, ATHLETE_A2, ATHLETE_B1, ATHLETE_B2]);
  await db.from("coaching_groups").delete().in("id", [GROUP_A_ID, GROUP_B_ID]);

  for (const uid of [COACH_A_ID, COACH_B_ID, ATHLETE_A1, ATHLETE_A2, ATHLETE_B1, ATHLETE_B2]) {
    await db.auth.admin.deleteUser(uid);
  }

  console.log("  Cleanup complete");
}

// ── Main ───────────────────────────────────────────────────────────────────

async function main() {
  console.log("=== KPI Snapshot Verification ===");
  console.log(`Target day: ${YESTERDAY_STR}`);

  try {
    await seedData();
    await runCompute();
    await verify();
    console.log("\n=== ALL CHECKS PASSED ===\n");
  } catch (err) {
    console.error("\n=== VERIFICATION FAILED ===");
    console.error(err);
    process.exit(1);
  } finally {
    await cleanup();
  }
}

main();
